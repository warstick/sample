import React from 'react'

import BBPromise from 'bluebird'
import PropTypes from 'prop-types'
import { NikeButton, NikeIcon, NikeModal } from '@gtm-styleguide/react-styleguide'
import { format } from '@gtm-av/js-i18n'
import { currentUser } from '@gtm-av/av-auth'
import { filterMap, forEach, filter, unique } from '@gtm-av/js-iterators'
import { loadData } from '../MyWorkspaceHeader/MyWorkspaceHeader.resolver'
import { shareUser, validateUserIds } from './WorkspaceNavigation.resolver'

const regex = {
  invalidCharactersRegexInShare: /(["#~`!<>@$%^*()+'={}[\];"?&.|/\\])/g,
  removeDashes: /[,()-]/g
}

export class ShareWorkspaceModal extends React.Component {
  constructor(props) {
    super(props)

    this.state = {
      loaded: false,
      serviceError: false,
      submitSharedErrors: false,
      sharedBoardTextarea: '',
      shareTextAreaErrorMessage: '',
      hasAuthorizedError: false,
      invalidUserIds: []
    }

    this.renderShareModal = this.renderShareModal.bind(this)
    this.closeShareModal = this.closeShareModal.bind(this)
    this.onTextareaChange = this.onTextareaChange.bind(this)
    this.onShareModalSubmit = this.onShareModalSubmit.bind(this)
    this.textAreaHasInvalidCharacters = this.textAreaHasInvalidCharacters.bind(this)
    this.shareModalInputDoesHaveInvalidCharacters = this.shareModalInputDoesHaveInvalidCharacters.bind(this)
  }

  static get propTypes() {
    return {
      workspace: PropTypes.object,
      isEnabled: PropTypes.boolean
    }
  }

  renderShareModal() {
    this.shareModalOpen = true

    const showShareError = () => {
      return (
        <div className='share-error-container'>
          <NikeIcon className='share-warning-icon' value='warning' size={30} />
          <span className='share-error-message-content'>
            {this.state.hasAuthorizedError && <span>{format('msgUnAuthorizedServerError')}</span>}
            {!this.state.hasAuthorizedError && this.state.submitSharedErrors && <span>{format('msgUnhandledServerError')}</span>}
            {this.state.shareTextAreaErrorMessage && <span>{this.state.shareTextAreaErrorMessage}</span>}
            {this.state.invalidUserIds.length > 0 && <span>{format('msgInvalidUserIds')} {this.state.invalidUserIds.join(',')} <br /> {format('msgCorrectErrors')}</span>}
            {(this.state.sharedBoardTextarea.length) >= 512 && <span>{format('msgMaxlength')}</span>}
          </span>
        </div>
      )
    }

    const content = () => {
      return (
        <div className='share-board-form'>
          <div className='share-input'>
            <div className='share-label'>{format('msgShareBoardWith')}</div>
            <textarea placeholder={format('lblEnterUserNames')} maxLength='512' onChange={this.onTextareaChange} />
          </div>
          {(this.state.sharedBoardTextarea.length) >= 512 && showShareError()}
          {
            (this.state.shareTextAreaErrorMessage || this.state.invalidUserIds.length > 0 || this.state.submitSharedErrors) && showShareError()
          }
        </div>
      )
    }

    const footer = () => (
      <div>
        <NikeButton dataAu='share-modal-share-btn' disabled={
          this.state.shareTextAreaErrorMessage || this.state.submitSharedErrors ||
                !!this.state.invalidUserIds.length ||
                this.state.sharedBoardTextarea.length <= 0 ||
                this.state.sharedBoardTextarea.length >= 512} className='share-modal-share-button' onClick={this.onShareModalSubmit} >
          {format('btnShare')}
        </NikeButton>
        <NikeButton dataAu='share-modal-cncl-btn' onClick={this.closeShareModal} className='share-modal-cancel-button'>{format('cancelBtn')}</NikeButton>
      </div>
    )

    this.shareModal = NikeModal.open(null, {
      heading: <div className='modal-heading' >{format('lblShareBoard')}</div>,
      content,
      className: 'share-modal',
      dismissable: true,
      footer,
      onClose: () => {
        this.shareModal.unmount()
        this.shareModal = null
        this.shareModalOpen = false
        this.setState({invalidUserIds: [], submitSharedErrors: false})
      }
    })
  }

  closeShareModal() {
    this.shareModal.close()
  }

    onTextareaChange = (textarea) => {
      this.state.sharedBoardTextarea = textarea.target.value.trim().replace(/\s/g, ',').replace(/,+/g, ',')
      textarea.target.value = this.state.sharedBoardTextarea
      this.textAreaHasInvalidCharacters(textarea)
      this.setState({invalidUserIds: [], submitSharedErrors: false, hasAuthorizedError: false})
      this.shareModal.update()
    }

    async analyzeInput() {
      const userIds = [...new Set(unique(this.state.sharedBoardTextarea.split(',')).filter(Boolean))]

      if (!userIds.length) {
        this.shareModal.update()

        return
      }

      if (userIds.indexOf(currentUser.userId) >= 0) {
        this.setState({invalidUserIds: [currentUser.userId]})
        this.shareModal.update()

        return
      }

      const validatedUsers = await validateUserIds(userIds)
      let shareSubmitState = {}

      if (!validatedUsers.invalidUserIds.length) {
        const sharedPromises = []

        forEach(validatedUsers.validUsers, (user) => {
          sharedPromises.push(shareUser(this.props.workspace.primaryRegion.level.id, user.userId, this.props.workspace.id))
        })
        const results = await BBPromise.all(sharedPromises)

        const submitErrorResults = filterMap(results, (res) => {
          if (res.error) {
            return res
          }
        })

        const hasAuthorizedError = filter(submitErrorResults, (error) => {
          return error.status === 401
        })

        shareSubmitState = {submitSharedErrors: (submitErrorResults.length > 0), submitErrorResults, hasAuthorizedError}
      }

      // if share modal is success
      if (shareSubmitState.submitErrorResults && shareSubmitState.submitErrorResults.length === 0) {
        this.closeShareModal()

        return
      }

      this.setState({...validatedUsers, ...shareSubmitState}, () => {
        this.shareModal.update()
      })
    }

    onShareModalSubmit() {
      this.analyzeInput()
    }

    textAreaHasInvalidCharacters(textarea) {
      if (this.shareModalInputDoesHaveInvalidCharacters(textarea) && textarea.target.value.trim().length > 0) {
        this.setState({shareTextAreaErrorMessage: format('msgInvalidCharactersShareModal'), invalidUserIds: []})
      }
      else {
        this.setState({shareTextAreaErrorMessage: null})
      }
    }

    shareModalInputDoesHaveInvalidCharacters(textarea) {
      const currentShareTextarea = textarea.target.value.trim()
      const hasInvalidCharactersInShare = regex.invalidCharactersRegexInShare.test(currentShareTextarea) || currentShareTextarea.length === 0

      // This is needed to override the /g parameter on regex that may be used elsewhere
      regex.invalidCharactersRegexInShare.lastIndex = 0

      return hasInvalidCharactersInShare
    }

    render() {
      const { isEnabled } = this.state

      return (
        <div key='share' data-au='share-btn' className={`share-option${isEnabled ? '' : ' read-only'}`} Onclick={isEnabled && this.renderShareModal}>
          <NikeIcon value='share' size={24} />
          <span>Share</span>
        </div>
      )
    }
}
