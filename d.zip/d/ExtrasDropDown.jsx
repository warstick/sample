import './ExtraDropdown.scss'
import React from 'react'
import PropTypes from 'prop-types'
import {ProductCollection, ProductCollectionView} from '@gtm-av/av-product-collection'
import {NikeFlyout, NikeIcon} from '@gtm-styleguide/react-styleguide'

import {ExportAssortment} from '../ExportAssortment/ExportAssortment'
import {ExportToFile} from '../ExportToFile/ExportToFile'
import {ExportExcel} from '../ExportExcel/ExportExcel'
import {NILPDownload} from '../NILPDownload/NILPDownload'
import {AvExportExcelModal} from '@gtm-av/av-react-components'
import {loadExtrasData} from './WorkspaceNavigation.resolver'
import {ExportApi} from '../../utils/export-api'
import { SaveAsWorkspaceModal } from './SaveAsWorkspaceModal'
import { ShareWorkspaceModal } from './ShareWorkspaceModal'
import { DeleteWorkspaceModal } from './DeleteWorkspaceModal'
export class ExtrasDropDown extends React.Component {
  static get contextTypes() {
    return {
      router: PropTypes.object.isRequired
    }
  }

  static get propTypes() {
    return {
      workspace: PropTypes.object,
      seasonCode: PropTypes.string,
      collection: PropTypes.oneOfType([
        PropTypes.instanceOf(ProductCollection),
        PropTypes.instanceOf(ProductCollectionView)
      ]),
      currentView: PropTypes.string,
      metadata: PropTypes.object,
      tooLargeToDisplayError: PropTypes.bool,
      regionId: PropTypes.number,
      selectons: PropTypes.object
    }
  }

  componentDidMount() {
    this.mounted = true
    loadExtrasData().then(() => {
      if (this.mounted) {
        this.setState({
          loaded: true
        })
      }
    })
  }

  componentWillUnmount() {
    this.mounted = false
  }

  constructor(props) {
    super(props)
    this.flyout = {open: false}
    this.state = {
      arrow: 'arrow-fill-down',
      loaded: false
    }

    this.toggleFlyout = this.toggleFlyout.bind(this)
    this.closingFlyout = this.closingFlyout.bind(this)
  }

  checkIfRouteIsMyWorkspace() {
    const { router } = this.context
    const { pathname } = router.location
    const myWorkspaceUrl = /\/my-workspace/

    return myWorkspaceUrl.test(pathname)
  }

  toggleFlyout() {
    this.flyout.open = !this.flyout.open
  }

  closingFlyout() {
    this.setState({'arrow': this.state.arrow === 'arrow-fill-up' ? 'arrow-fill-down' : 'arrow-fill-up'})
  }

  render() {
    const {collection, seasonCode, currentView, metadata, tooLargeToDisplayError, regionId, workspace, selectons} = this.props
    const { isOwner } = this.context.permissions;

    // place icon value
    return (
      <span id='extras-dropdown' >
        {this.state.loaded
          ? <div data-au='extras-document-dd' id='extras-dropdown-toggle' ref='extras-dropdown-toggle'
            onClick={this.toggleFlyout} data-tooltip='Actions'>
            <div id='action-menu' >
              <NikeIcon value='actions-menu' size={32} />
            </div >
          </div >
          : <NikeIcon value='spinner-4' size='medium' />
        }
        <NikeFlyout className='flyoutExtras' autoClose showArrow ref={(ref) => this.flyout = ref}
          anchorSelector='#extras-dropdown-toggle'
          direction='bottom' open={this.flyout.open} edgeSpacing={18} anchorSpacing={-14}
          onClose={this.closingFlyout} onOpen={this.closingFlyout} >
          <div className='menu-options' >
            <ExportAssortment currentView={currentView} collection={collection} seasonCode={seasonCode}
              flyout={this.flyout} />
            <ExportToFile flyout={this.flyout} currentView={currentView} metadata={metadata} />
            <AvExportExcelModal currentView={currentView} collection={collection} metadata={metadata}
              count={(collection && collection.rawObjects.length) || 0} seasonCode={seasonCode} flyout={this.flyout} regionId={regionId}
              filter={metadata.filter} exportApi={ExportApi.sendPricePointExportRequest} />
            <ExportExcel flyout={this.flyout} />
            <NILPDownload collection={collection} currentView={currentView}
              tooLargeToDisplayError={tooLargeToDisplayError} />
            {this.checkIfRouteIsMyWorkspace() &&
            <div className={'workspace-nav'}>
              <ShareWorkspaceModal workspace={workspace} isEnabled={isOwner} />
              <SaveAsWorkspaceModal workspace={workspace} selections={selectons} isEnabled={isOwner} />
              <DeleteWorkspaceModal workspace={workspace} isEnabled={isOwner} />
            </div>}
          </div>
        </NikeFlyout >
      </span>
    )
  }
}
