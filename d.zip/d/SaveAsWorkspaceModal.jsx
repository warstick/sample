// import './MyWorkspaceHeader.scss'
import React from 'react'

import PropTypes from 'prop-types'
import { format } from '@gtm-av/js-i18n'
import { filterMap } from '@gtm-av/js-iterators'
import { loadData } from '../MyWorkspaceHeader/MyWorkspaceHeader.resolver'
import { createMyBoardAndStoryboard } from './WorkspaceNavigation.resolver'
import { referenceData } from '@gtm-av/av-reference-data'
import { NikeButton, NikeIcon, NikeModal, NikeDropdownSelect } from '@gtm-styleguide/react-styleguide'

const regex = {
  invalidCharactersRegex: /(["#~`!<>@$%^*()+'={}[\];"?&,.|/\\])/g,
  removeDashes: /[,()-]/g
}

export class SaveAsWorkspaceModal extends React.Component {
  constructor(props) {
    super(props)

    this.state = {
      canSaveAs: false,
      newWorkspaceName: '',
      referenceData: referenceData
    }

    this.renderSaveAsModal = this.renderSaveAsModal.bind(this)
    this.closeSaveAsModal = this.closeSaveAsModal.bind(this)
    this.saveAsWorkspace = this.saveAsWorkspace.bind(this)
    this.onAssortmentLevelSelection = this.onAssortmentLevelSelection.bind(this)
    this.onRegionSelection = this.onRegionSelection.bind(this)
  }

  static get contextTypes() {
    return {
      myBoards: PropTypes.object,
      updateView: PropTypes.func.isRequired
    }
  }

  static get propTypes() {
    return {
      workspace: PropTypes.object,
      selections: PropTypes.object,
      isEnabled: PropTypes.boolean
    }
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.selections !== nextProps.selections) {
      this.onAssortmentLevelSelection(nextProps.selections.assortmentLevel, true, nextProps.selections.region)
    }
  }

  updateModal() {
    if (this.saveAsModalOpen) {
      this.saveAsModal.update()
    }
  }

  getAssortmentLevels() {
    let assortmentLevels = []

    this.state.referenceData.assortmentLevels.forEach((assortmentLevel) => {
      if (assortmentLevel.id !== 4) {
        assortmentLevels.push({label: assortmentLevel.description, key: assortmentLevel.id, value: assortmentLevel.id})
      }
    })

    return assortmentLevels.sort(function(a, b) {
      return a.label < b.label
    })
  }

  getRegions(regions) {
    const regionsForAssortment = regions.map((region) => {
      return {label: region.description.toUpperCase(), key: region.id, value: region.id}
    })

    return regionsForAssortment.sort(function(a, b) {
      return a.label.replace(regex.removeDashes, '') < b.label.replace(regex.removeDashes, '') ? -1 : 1
    })
  }

  renderSaveAsModal() {
    this.saveAsModalOpen = true
    let assortmentLevels = this.getAssortmentLevels()
    const onChange = (event) => {
      if (event.target.value.match(regex.invalidCharactersRegex)) {
        this.setState({
          newWorkspaceName: event.target.value,
          showSaveAsWorkspaceError: true,
          isCreateButtonEnabled: false,
          errorMessage: format('msgInvalidCharacters')
        })
      }
      else if (event.target.value.length < 1) {
        this.setState({
          newWorkspaceName: event.target.value,
          showSaveAsWorkspaceError: true,
          errorMessage: format('lblMinimumCharacterCountError'),
          isCreateButtonEnabled: false
        })
      }
      else {
        this.setState({
          showSaveAsWorkspaceError: false, errorMessage: null, newWorkspaceName: event.target.value, isCreateButtonEnabled: this.isCreateButtonEnabled()
        })
      }

      this.updateModal()
    }

    const showError = () => {
      return (
        <div className='footer-save-as-workspace-error-container'>
          <NikeIcon className='save-as-workspace-warning-icon' value='warning' size={30} />
          <p className='save-as-workspace-error-message-content'>{this.state.errorMessage}</p>
        </div>
      )
    }

    const content = () => {
      return (
        <div className='create-workspace-form'>
          <div className='save-as-input'>
            <div className='save-as-label'>{format('lblEnterYourGroupName')}</div>
            <input placeholder={format('lblEnterYourGroupName')} onChange={onChange}
            />
            {this.state.showSaveAsWorkspaceError && this.isDuplicateError ? showError() : null }
          </div>
          <div className='save-as-label'>{format('lblAssortmentLevel')}</div>
          <NikeDropdownSelect
            dataAu='add-ws-panel-lvl-cont'
            className='save-as-modal-dropdown'
            onChange={this.onAssortmentLevelSelection}
            value={this.state.assortmentLevelSelection}
            placeholder={format('lblSelect')}
            options={assortmentLevels} />
          {
            this.state.regionVisible ? [
              <div className='save-as-label' key='add-ws-panel-region-label'>{format('lblTypeOfRegion')}</div>,
              <NikeDropdownSelect
                className='save-as-modal-dropdown'
                dataAu='add-ws-panel-rgn'
                key='add-ws-panel-rgn'
                onChange={this.onRegionSelection}
                value={this.state.regionSelection}
                placeholder={format('lblSelect')} slot='options'
                options={this.state.regionValues} />] : null
          }
        </div>
      )
    }

    const footer = () => (
      <div>
        {this.state.showSaveAsWorkspaceError && !this.isDuplicateError ? showError() : null }
        <NikeButton dataAu='save-as-modal-save-btn' onClick={this.saveAsWorkspace}
          disabled={!this.state.isCreateButtonEnabled || this.state.showSaveAsWorkspaceError}
          className='save-as-workspace-modal-save-button'>{format('btnSave')}</NikeButton>
        <NikeButton dataAu='save-as-modal-cncl-btn' onClick={this.closeSaveAsModal} className='save-as-workspace-modal-cancel-button'>{format('cancelBtn')}</NikeButton>
      </div>
    )

    this.saveAsModal = NikeModal.open(null, {
      heading: <div className='modal-heading' >{ format('lblSaveAsWorkspace') }</div>,
      content,
      className: 'save-as-modal',
      dismissable: true,
      footer,
      onClose: () => {
        this.saveAsModal.unmount()
        this.saveAsModal = null
        this.saveAsModalOpen = false
        this.setState({ showSaveAsWorkspaceError: false, errorMessage: null })
      }
    })
  }

  closeSaveAsModal() {
    this.saveAsModal.close()
  }

  async saveAsWorkspace() {
    const { workspace } = this.props

    this.isDuplicateError = false

    try {
      await createMyBoardAndStoryboard({
        workspace,
        name: this.state.newWorkspaceName,
        assortmentLevel: this.state.assortmentLevelSelection.value,
        regionId: this.state.regionSelection.value
      })

      this.context.myBoards.refresh()
      this.context.updateView()
      this.saveAsModal.close()
    }

    catch (error) {
      let msg

      if (error && error.data && Array.isArray(error.data.errors) && error.data.errors[0]) {
        this.isDuplicateError = error.data.errors[0].developerMessage.indexOf('ER_DUP_ENTRY') > -1
        msg = this.isDuplicateError ? format('msgMyWorkspaceDuplicateName') : format('msgUnhandledServerError')
      }
      else {
        msg = format('msgUnhandledServerError')
      }

      this.setState({
        showSaveAsWorkspaceError: true,
        errorMessage: msg
      })
      this.saveAsModal.update()
    }
  }

  isCreateButtonEnabled() {
    if (this.state.assortmentLevelSelection && this.state.assortmentLevelSelection.value && this.state.assortmentLevelSelection.value !== 1) {
      return this.state.newWorkspaceName.length > 0 && this.state.regionSelection
    }
    else {
      return (this.state.assortmentLevelSelection || {}).value
    }
  }

  isWorkspaceNameValid() {
    return !this.state.displayError && this.state.newWorkspaceName && this.state.newWorkspaceName.length > 0
  }

  onRegionSelection = (event) => {
    if (event) {
      this.setState({regionSelection: event, isCreateButtonEnabled: this.isWorkspaceNameValid()})
      this.updateModal()
    }
  }

  onAssortmentLevelSelection = (event, isFromProps, propsRegion) => {
    if (event) {
      let level = event.value

      if (level !== 1) {
        const regions = filterMap(this.state.referenceData.regions, (region) => {
          if (region.level.id === level) {
            return region
          }
        })

        this.setState({
          assortmentLevelSelection: event,
          regionSelection: null,
          isCreateButtonEnabled: false,
          regionValues: this.getRegions(regions),
          regionVisible: true
        }, () => {
          if (isFromProps) {
            this.onRegionSelection(propsRegion)
          }
          else {
            this.updateModal()
          }
        })
      }
      else {
        this.setState({
          assortmentLevelSelection: event,
          regionSelection: {value: 0},
          regionVisible: false,
          isCreateButtonEnabled: this.isWorkspaceNameValid()
        }, () => {
          if (isFromProps) {
            this.onRegionSelection(propsRegion)
          }
          else {
            this.updateModal()
          }
        })
      }
    }
  }

  render() {
    const { isEnabled } = this.props

    return (
      <div data-au='save-as-btn' className={`save-as-option${isEnabled ? '' : ' read-only'}`}
        onClick={isEnabled && this.renderSaveAsModal}>
        <NikeIcon value='save' size={25} />
        <span>Save As</span>
      </div>
    )
  }
}
