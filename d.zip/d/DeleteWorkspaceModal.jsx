// import './MyWorkspaceHeader.scss'
import React from 'react'
import PropTypes from 'prop-types'

import { format } from '@gtm-av/js-i18n'

import { NikeButton, NikeIcon, NikeModal } from '@gtm-styleguide/react-styleguide'
import { deleteMyWorkspaces } from './WorkspaceNavigation.resolver'

export class DeleteWorkspaceModal extends React.Component {
  static get contextTypes() {
    return {
      router: PropTypes.object.isRequired
    }
  }
  static get propTypes() {
    return {
      workspace: PropTypes.object,
      isEnabled: PropTypes.boolean
    }
  }

  constructor(props) {
    super(props)

    this.state = {}

    this.renderDeleteModal = this.renderDeleteModal.bind(this)
    this.deleteWorkspace = this.deleteWorkspace.bind(this)
    this.closeDeleteModal = this.closeDeleteModal.bind(this)
  }

  renderDeleteModal() {
    const content = () => (
      <div>
        <p>{ format('msgDeleteMyWorkspace') }</p>
      </div>
    )

    const footer = () => (
      <div>
        <NikeButton dataAu='delete-modal-del-btn' onClick={this.deleteWorkspace} className='delete-workspace-modal-delete-button'>{format('btnDelete')}</NikeButton>
        <NikeButton dataAu='delete-modal-cncl-btn' onClick={this.closeDeleteModal} className='delete-workspace-modal-cancel-button'>{format('cancelBtn')}</NikeButton>
        {this.state.showDeleteWorkspaceError ? <div className='footer-delete-workspace-error-container'>
          <NikeIcon className='delete-workspace-warning-icon' value='warning' size={30} />
          <p className='delete-workspace-error-message-content'>{this.state.deleteWorkspaceError}</p>
        </div> : null }
      </div>
    )

    this.deleteModal = NikeModal.open(null, {
      heading: <h2>{ format('lblDeleteWorkspace') }</h2>,
      dismissable: true,
      content,
      footer,
      onClose: () => {
        this.deleteModal.unmount()
        this.deleteModal = null
        this.setState({ showDeleteWorkspaceError: false })
      }
    })
  }

  closeDeleteModal() {
    this.deleteModal.close()
  }

  deleteWorkspace() {
    const routerParams = this.context.router.params
    const seasonCode = routerParams.seasonCode
    const regionId = routerParams.regionId

    deleteMyWorkspaces(this.props.workspace.id)
      .then(() => {
        this.deleteModal.close()
        this.context.router.push('/workspace/' + seasonCode + '/' + regionId)
      }).catch((error) => {
        console.error('Error deleting workspace: ', error)
        this.setState({
          showDeleteWorkspaceError: true,
          deleteWorkspaceError: format('msgUnhandledServerError')
        })
      })
  }

  render() {
    const { isEnabled } = this.props

    return (
      <div key='delete' data-au='delete-ws-trash-btn'
        className={`trash-can-option${isEnabled ? '' : ' read-only'}`}
        onClick={isEnabled && this.renderDeleteModal}>
        <NikeIcon value='trash' size={25} />
        <span>Delete</span>
      </div>
    )
  }
}
